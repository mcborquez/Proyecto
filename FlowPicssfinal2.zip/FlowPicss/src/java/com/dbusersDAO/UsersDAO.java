/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dbusersDAO;

import DBconnection.ConnectionDB;
import Interfaces.CRUD;
import com.dbusers.Users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MAU-Pc
 */
public class UsersDAO implements CRUD{
    
    PreparedStatement ps;
    ResultSet rs;
    Users u=new Users();
    @Override    
    
    public List listar() {        
        ArrayList<Users>list=new ArrayList<>();
        String sql="select * from usuario";
        Connection con=null;
        try{    
            con=ConnectionDB.open();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){                
                Users us=new Users();
                us.setId(rs.getInt("ID"));
                us.setPasswordc(rs.getString("password"));
                us.setUserc(rs.getString("user"));
                list.add(us);
            }
        }catch (SQLException ex){
                System.out.println("Error SQL"+ex.getMessage());
        }finally{
            try{
            if(con!=null){
                con.close();
            }
            if(ps!=null){
                ps.close();
            }
        }catch (SQLException ex){
                System.out.println("Error Closing "+ex.getMessage());
        }
        return list;}
    }

    @Override
    public Users list(int id) { //Edit fields for one user
        String sql="select * from usuario where Id="+id;
        Connection con=null;
        try{    
            con=ConnectionDB.open();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                u.setId(rs.getInt("ID"));
                u.setPasswordc(rs.getString("password"));
                u.setUserc(rs.getString("user"));
                
            }
        }catch (SQLException ex){
                System.out.println("Error SQL"+ex.getMessage());
        }finally{
            try{
            if(con!=null){
                con.close();
            }
            if(ps!=null){
                ps.close();
            }
        }catch (SQLException ex){
                System.out.println("Error Closing "+ex.getMessage());
        }
        
        }return u;}

    @Override
    public boolean add(Users us) { //Add one user to database
        String sql="insert into usuario(user,password)values('"+us.getUserc()+"','"+us.getPasswordc()+"')";
        Connection con=null;
        try{
            con=ConnectionDB.open();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }
    catch (SQLException ex){
                System.out.println("Error SQL"+ex.getMessage());
        }finally{
            try{
            if(con!=null){
                con.close();
            }
            if(ps!=null){
                ps.close();
            }
        }catch (SQLException ex){
                System.out.println("Error Closing "+ex.getMessage());
        }
        
        }   
    return false;}
    

    @Override
    public boolean edit(Users us) { //        
        String sql="update usuario set user='"+us.getUserc()+"',password='"+us.getPasswordc()+"'where id="+us.getId();
        Connection con=null;
        try {
            con=ConnectionDB.open();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }catch (SQLException ex){
                System.out.println("Error SQL"+ex.getMessage());
        }finally{
            try{
            if(con!=null){
                con.close();
            }
            if(ps!=null){
                ps.close();
            }
        }catch (SQLException ex){
                System.out.println("Error Closing "+ex.getMessage());
        }
        
        }return false;}

    @Override
    public boolean eliminar(int id) {
        String sql="delete from usuario where id="+id;
        Connection con=null;
        try{
            con=ConnectionDB.open();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }
    catch (SQLException ex){
                System.out.println("Error SQL"+ex.getMessage());
        }finally{
            try{
            if(con!=null){
                con.close();
            }
            if(ps!=null){
                ps.close();
            }
        }catch (SQLException ex){
                System.out.println("Error Closing "+ex.getMessage());
        }
        
        }return false;    
    }

    @Override
    public int validar(Users u) {
        int r=0;
        String sql="Select * from usuario where user=? and password=?";
        Connection con=null;
        try{
            con=ConnectionDB.open();
            ps=con.prepareStatement(sql);
            ps.setString(1, u.getUserc());
            ps.setString(2, u.getPasswordc());
            rs=ps.executeQuery();
            while(rs.next()){
                r=r+1;
                u.setUserc(rs.getString("user"));
                u.setPasswordc(rs.getString("password"));
            }
            if(r==1){
                return 1;
            }else{
                return 0;
            }
            
        }catch (SQLException ex){
                System.out.println("Error SQL"+ex.getMessage());
        }finally{
            try{
            if(con!=null){
                con.close();
            }
            if(ps!=null){
                ps.close();
            }
        }catch (SQLException ex){
                System.out.println("Error Closing "+ex.getMessage());
        }
        
        }return 0;    
    
}}