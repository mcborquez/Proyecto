/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dbusers;

/**
 *
 * @author Maipu_lab02
 */
public class Users {
     int id;
     private String userc; //c = references "Class"
     private String passwordc;

    public Users() {    }

    public Users(String userc, String passwordc) {
        this.userc = userc;
        this.passwordc = passwordc;
    } 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserc() {
        return userc;
    }

    public void setUserc(String userc) {
        this.userc = userc;
    }

    public String getPasswordc() {
        return passwordc;
    }

    public void setPasswordc(String passwordc) {
        this.passwordc = passwordc;
    }

    
}
