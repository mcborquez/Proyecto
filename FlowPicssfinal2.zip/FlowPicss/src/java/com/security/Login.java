/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.security;

import com.dbusers.Users;
import com.dbusersDAO.UsersDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Maipu_lab02
 */
public class Login extends HttpServlet {
Users us= new Users();
UsersDAO dao= new UsersDAO();
int r;

/*protected void forwardToPage(final HttpServletRequest request, 
                           final HttpServletResponse response,
                           String url) 
throws IOException, ServletException
{
  RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
  dispatcher.forward(request,response);
}
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {/*
        response.setContentType("text/html;charset=UTF-8");
        String accion= request.getParameter("accion");
        
        if("Ingresar".equals(accion)){
            String user=request.getParameter("usr");
            String pass=request.getParameter("passw");
            us.setUserc(user);
            us.setPasswordc(pass);           
            r=dao.validar(us);
            if(r==1){
                request.getRequestDispatcher("Home.jsp").forward(request, response);
            }
            else{
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
            
        }*/
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
    }
    
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


   @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        String accion= request.getParameter("accion");
        
        if("Ingresar".equals(accion)){
            String user=request.getParameter("usr");
            String pass=request.getParameter("passw");
            us.setUserc(user);
            us.setPasswordc(pass);           
            r=dao.validar(us);
            if(r==1){
                request.getSession().setAttribute("userc",user);
                request.getSession().setAttribute("passwordc", pass);
                request.getRequestDispatcher("Home.jsp").forward(request, response);
            }
            else{
                request.getSession().invalidate();
                request.getRequestDispatcher("index.jsp").forward(request, response);
                
            }
        }
            else{
                 request.getSession().invalidate();
                 request.getRequestDispatcher("index.jsp").forward(request, response);   
                    }
            
        }
        
       /* String user=request.getParameter("usr");
        String password=request.getParameter("passw");
        
        UsersW.add(new Users("System","root"));
        UsersW.add(new Users("admin","admin"));
        UsersW.add(new Users("MauricioC","rootadmin"));
        UsersW.add(new Users("JorgeR","moderator"));     
        
        
       for(int i=0;i<UsersW.size();i++){            
        Users u= (Users) UsersW.get(i);
           System.out.println(""+u.getUserc()+" "+u.getPasswordc());
           if(user.equals(u.getUserc())&&password.equals(u.getPasswordc()))
           {
               forwardToPage(request,response,"/Home.jsp");
           }
           
       }       
        
      //request.getRequestDispatcher("index.jsp").forward(request, response);

        
        
       
       
        

            
       
        
      */ 


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
