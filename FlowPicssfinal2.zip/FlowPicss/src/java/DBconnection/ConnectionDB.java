/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DBconnection;


import java.sql.*;

/**
 *
 * @author MAU-Pc
 */
public class ConnectionDB {
    private static Connection con;
    private static String bd="flowpics";
    public static String usuario="root";
    public static String passw="root";
    public static String url="jdbc:mysql://localhost:3308/"+bd; //?autoReconnect=true&useSSL=false";
    public static Connection open() throws SQLException{
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(url,usuario,passw);
        }catch (ClassNotFoundException ce){
            System.out.println("Class Not Found Check jdbc Driver");
        }catch (SQLException e){
            System.out.println("Error en la conexion..."+e.getMessage());
            throw e;
        }
        return con;
    }
    public static void close(){
        try{
            if(con!=null){
                con.close();
            }
        }catch (SQLException e){
            System.out.println("Error: No se pudo cerrar la conexion "+e);
        }
    }
}