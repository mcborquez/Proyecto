/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import com.dbusers.Users;
import java.util.List;

/**
 *
 * @author MAU-Pc
 */
public interface CRUD {
    public int validar(Users us);
    public List listar();
    public Users list(int id);
    public boolean add(Users us);
    public boolean edit(Users us);
    public boolean eliminar(int id);
    
}
